### how to run script:


```bash
chmod +x script.sh
./script.sh n_1 n_2 n_3 n_4
```
n_i: number of fields in harvesting problem.
We run the script to get results for multiple number of fields.