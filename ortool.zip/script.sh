#!/bin/bash
python3 ortool.py $1 > output_$1.txt
python3 ortool.py $2 > output_$2.txt
python3 ortool.py $3 > output_$3.txt
python3 ortool.py $4 > output_$4.txt
